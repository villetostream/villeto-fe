import { useState, useEffect, type ChangeEvent } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useForm,
  useFieldArray,
  UseFormReturn,
  SubmitHandler,
  FieldValue,
  FieldValues,
} from "react-hook-form";
import { z } from "zod";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Form, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { toast } from "sonner";
import { Label } from "../ui/label";
import Link from "next/link";
import FormFieldInput from "../form fields/formFieldInput";
import FormFieldSelect from "../form fields/formFieldSelect";
import FormFieldTextArea from "../form fields/formFieldTextArea";
import { Trash } from "iconsax-reactjs";
import FormFieldCalendar from "../form fields/FormFieldCalendar";
import SuccessModal from "../modals/SuccessModal";
import { SplitExpense } from "./split/SplitExpenseform";
import { splitExpenseSchema } from "./split/splitSchema";
import { useRouter, useSearchParams } from "next/navigation";
import { useAxios } from "@/hooks/useAxios";
import { API_KEYS } from "@/lib/constants/apis";
import { Loader2 } from "lucide-react";
import { useSubmitExpense, useSaveExpenseAsDraft } from "@/lib/react-query/expenses";


export function ManualExpenseForm() {
  const [files, setFiles] = useState<string[]>([]);
  const [categories, setCategories] = useState<ExpenseCategory[]>([]);
  const [isLoadingCategories, setIsLoadingCategories] = useState(true);

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "expenses",
  });

  const amountFieldsNames = Array(fields.length)
    .fill(null)
    .map(
      (_, index) => `expenses.${index}.amount`,
    ) as Array<`expenses.${number}.amount`>;

  const amounts = form.watch(amountFieldsNames);

  const receiptFieldsNames = Array(fields.length)
    .fill(null)
    .map(
      (_, index) => `expenses.${index}.receipt`,
    ) as Array<`expenses.${number}.receipt`>;
  const receipts = form.watch(receiptFieldsNames);

  const hasAllReceipts = fields.every((_, idx) =>
    Boolean(files[idx] || receipts?.[idx]),
  );

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  };

  const onReceiptSelect = async (
    expenseIndex: number,
    e: ChangeEvent<HTMLInputElement>,
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Please upload an image receipt.");
      return;
    }

    try {
      const base64 = await fileToBase64(file);
      setFiles((prev) => {
        const next = [...(prev ?? [])];
        next[expenseIndex] = base64;
        return next;
      });
      form.setValue(`expenses.${expenseIndex}.receipt`, base64, {
        shouldValidate: true,
        shouldDirty: true,
      });
      form.clearErrors(`expenses.${expenseIndex}.receipt`);
    } catch {
      toast.error("Failed to upload receipt. Please try again.");
    } finally {
      e.target.value = "";
    }
  };

  const addExpense = () => {
    append({
      title: "",
      vendor: "",
      amount: 0,
      category: "",
      description: "",
      transactionDate: new Date(),
      receipt: "",
    });
  };

  const removeExpense = (index: number) => {
    if (fields.length > 1) {
      remove(index);
    } else {
      toast.error("You must have at least one expense item");
    }
  };

  // Helper function to extract pure base64 string from data URL
  const extractBase64 = (dataUrl: string): string => {
    if (!dataUrl || typeof dataUrl !== "string") return "";

    // If it's already a pure base64 string (no data: prefix), return as-is
    if (!dataUrl.startsWith("data:")) {
      return dataUrl.trim();
    }

    // Remove data:image/...;base64, prefix if present
    const base64Match = dataUrl.match(/^data:image\/[^;]+;base64,(.+)$/);
    if (base64Match && base64Match[1]) {
      return base64Match[1].trim();
    }

    // If it's a data URL but doesn't match the pattern, try to extract after comma
    const commaIndex = dataUrl.indexOf(",");
    if (commaIndex !== -1) {
      return dataUrl.substring(commaIndex + 1).trim();
    }

    // Fallback: return empty string if we can't parse it
    console.warn("Could not extract base64 from:", dataUrl.substring(0, 50));
    return "";
  };

  // Build payload for backend submission (reusable for both submit and draft)
  const buildExpensePayload = (
    data: ExpenseFormValues,
    includeReceipts: boolean,
  ) => {
    // Validate all categories exist
    const invalidCategories = data.expenses.filter(
      (expense) => !categories.find((cat) => cat.name === expense.category),
    );

    if (invalidCategories.length > 0) {
      throw new Error(
        "Invalid category selected. Please ensure all expenses have valid categories.",
      );
    }

    // Build expenses array
    const expensesPayload = data.expenses.map((expense, idx) => {
      const category = categories.find((cat) => cat.name === expense.category);
      if (!category) {
        throw new Error(`Category not found: ${expense.category}`);
      }

      // Build base expense object
      const expenseObj: {
        title: string;
        merchantName: string;
        description: string;
        expenseCategoryId: string;
        amount: number;
        receiptImage?: string;
      } = {
        title: expense.title,
        merchantName: expense.vendor,
        description: expense.description || "",
        expenseCategoryId: category.categoryId,
        amount: Number(expense.amount),
      };

      // Only include receiptImage if we have a receipt AND includeReceipts is true
      if (includeReceipts) {
        const receiptBase64 = files[idx] || expense.receipt || "";
        const receiptImage = extractBase64(receiptBase64);

        // Only add receiptImage property if it's not empty
        if (receiptImage && receiptImage.trim() !== "") {
          expenseObj.receiptImage = receiptImage;
        }
        // If receiptImage is empty but includeReceipts is true, don't add the property at all
      }

      return expenseObj;
    });

    return {
      reportTitle: reportName || "Expense Report",
      expenses: expensesPayload,
    };
  };



  const onSubmit = async (data: ExpenseFormValues) => {
    // Receipt is mandatory for final submission.
    const missingReceiptIndexes = data.expenses
      .map((expense, idx) => {
        const receiptBase64 = files[idx] || expense.receipt;
        return receiptBase64 ? null : idx;
      })
      .filter((v): v is number => v !== null);

    if (missingReceiptIndexes.length > 0) {
      missingReceiptIndexes.forEach((idx) => {
        form.setError(`expenses.${idx}.receipt`, {
          type: "manual",
          message: "Receipt is required to submit.",
        });
      });
      toast.error("Please upload a receipt before submitting.");
      return;
    }

    // Validate splits
    const invalidSplits = data.expenses.some((expense) => {
      if (expense.splits && expense.splits.length > 0) {
        const totalSplitAmount = expense.splits.reduce(
          (sum, split) => sum + split.amount,
          0,
        );
        return Math.abs(totalSplitAmount - expense.amount) > 0.01;
      }
      return false;
    });

    if (invalidSplits) {
      toast.error("Total split amounts must equal the expense amount");
      return;
    }

    // Build payload with receipts (required for final submission)
    let payload;
    try {
      payload = buildExpensePayload(data, true);
    } catch (error: any) {
      toast.error(error.message || "Invalid expense data");
      return;
    }

    // Log payload for debugging
    console.log("Submitting expense payload:", payload);

    submitExpense({ ...payload, status: "pending" }); // Use the mutation
  };

  // Prepare category options for FormFieldSelect
  const categoryOptions = categories.map((category) => ({
    label: category.name,
    value: category.name,
  }));

  return (
    <>
      <SuccessModal
        isOpen={IsSuccess}
        onClose={() => {
          successToggle();
        }}
        onClick={() => {}}
        title="Expense Submitted"
        description="Your expense has been successfully submitted."
        buttonText="Back to Dashboard"
      />
      <div>
        <>
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(
                onSubmit as SubmitHandler<FieldValues>,
              )}
              className="space-y-6 px-6 pb-6"
            >
              {/* Modern Report Header */}
              <div className="bg-gradient-to-r from-primary/5 to-primary/10 rounded-xl px-6 py-3 border border-primary/20 shadow-sm w-full flex items-center justify-between">
                <p className="text-base font-semibold text-foreground">
                  {reportName || "Expense Report"}
                </p>
                <p className="text-base font-semibold text-foreground">
                  {reportDate}
                </p>
              </div>

              {/* Loading state for categories */}
              {isLoadingCategories && (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  <span className="ml-2 text-muted-foreground">
                    Loading expense categories...
                  </span>
                </div>
              )}

              {/* Dynamic Expense Forms */}
              {!isLoadingCategories && (
                <div className="space-y-6">
                  {/* If multiple expenses, render each section inside an accordion; otherwise render plain */}
                  {fields.length > 1 ? (
                    <Accordion
                      type="multiple"
                      defaultValue={["expense-0"]}
                      className="w-full"
                    >
                      {fields.map((field, index) => {
                        const amount = amounts[index] || 0;
                        return (
                          <AccordionItem
                            key={field.id}
                            value={`expense-${index}`}
                          >
                            <AccordionTrigger className="px-4 py-3 bg-gray-50 rounded-md text-left">
                              <div className="flex w-full justify-between items-center">
                                <div className="flex items-center gap-3">
                                  <span className="font-medium">
                                    {form.getValues(
                                      `expenses.${index}.title`,
                                    ) || `Expense ${index + 1}`}
                                  </span>
                                  <span className="text-sm text-muted-foreground flex items-center gap-3">
                                    <span>
                                      {form.getValues(
                                        `expenses.${index}.vendor`,
                                      ) || "No vendor"}
                                    </span>
                                    <span>•</span>
                                    <span>
                                      $
                                      {Number(
                                        form.getValues(
                                          `expenses.${index}.amount`,
                                        ) || 0,
                                      ).toLocaleString()}
                                    </span>
                                  </span>
                                </div>
                                {fields.length > 1 && index != 0 && (
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="sm"
                                    className="hover:bg-destructive/10"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      removeExpense(index);
                                    }}
                                  >
                                    <Trash className="h-4 w-4 text-destructive" />
                                  </Button>
                                )}
                              </div>
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="p-0 gap-8 relative flex items-start px-6 justify-between w-full">
                                <div className="space-y-5 max-w-lg flex flex-col pr-16">
                                  <FormFieldInput
                                    control={form.control}
                                    name={`expenses.${index}.title`}
                                    label="Expense Title"
                                    placeholder="Enter a title for this expense"
                                  />
                                  <SplitExpense
                                    control={form.control}
                                    expenseIndex={index}
                                    totalAmount={amount}
                                  />

                                  <div className="grid grid-cols-2 gap-4">
                                    <FormFieldInput
                                      control={form.control}
                                      name={`expenses.${index}.amount`}
                                      label="Amount"
                                      placeholder="Enter Amount"
                                      type="number"
                                      inputMode="numeric"
                                    />
                                    <FormFieldSelect
                                      control={form.control}
                                      name={`expenses.${index}.category`}
                                      values={categoryOptions}
                                      placeholder="Select Category"
                                      label="Expense Category"
                                    />
                                  </div>

                                  <div className="grid grid-cols-2 gap-4">
                                    <FormFieldInput
                                      control={form.control}
                                      name={`expenses.${index}.vendor`}
                                      label="Merchant"
                                      placeholder="Enter Merchant"
                                    />
                                    <FormFieldCalendar
                                      control={form.control}
                                      name={`expenses.${index}.transactionDate`}
                                      label="Transaction Date"
                                    />
                                  </div>

                                  <FormFieldTextArea
                                    control={form.control}
                                    label="Description"
                                    name={`expenses.${index}.description`}
                                    placeholder=""
                                  />

                                  {index === fields.length - 1 && (
                                    <Button
                                      type="button"
                                      variant={"link"}
                                      className="text-primary underline text-base font-bold leading-[150%] w-fit ml-auto place-self-end"
                                      onClick={addExpense}
                                    >
                                      Add Another
                                    </Button>
                                  )}
                                </div>
                                <div className="max-w-sm">
                                  <Label className="text-xs leading-[125%] font-normal text-foreground mb-1.5 block">
                                    Receipt
                                  </Label>
                                  <div className="rounded-lg border border-border bg-white p-3 h-[420px] flex items-center justify-center">
                                    {files[index] ? (
                                      <img
                                        src={files[index]}
                                        alt="Uploaded receipt"
                                        className="w-full h-full object-contain"
                                      />
                                    ) : (
                                      <div className="text-sm text-muted-foreground text-center px-6 space-y-3">
                                        <div className="text-muted-foreground font-medium">
                                          No receipt uploaded for this item.
                                        </div>
                                        <div className="text-muted-foreground">
                                          Receipt is required for final
                                          submission. You can save as draft
                                          without a receipt.
                                        </div>
                                        <input
                                          id={`receipt-input-${index}`}
                                          type="file"
                                          accept="image/*"
                                          aria-label={`Upload receipt for item ${index + 1}`}
                                          className="hidden"
                                          onChange={(e) =>
                                            onReceiptSelect(index, e)
                                          }
                                        />
                                        <Button
                                          type="button"
                                          variant="outlinePrimary"
                                          onClick={() => {
                                            document
                                              .getElementById(
                                                `receipt-input-${index}`,
                                              )
                                              ?.click();
                                          }}
                                        >
                                          Continue to upload receipt
                                        </Button>
                                      </div>
                                    )}
                                  </div>
                                  <FormField
                                    control={form.control}
                                    name={`expenses.${index}.receipt`}
                                    render={() => (
                                      <FormItem className="pt-2">
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                </div>
                              </div>
                            </AccordionContent>
                          </AccordionItem>
                        );
                      })}
                    </Accordion>
                  ) : (
                    fields.map((field, index) => {
                      const amount = amounts[index] || 0;
                      return (
                        <div
                          key={field.id}
                          className="p-0 gap-8 relative flex items-start px-6 justify-between w-full"
                        >
                          <div className="space-y-5 max-w-lg flex flex-col pr-16">
                            {fields.length > 1 && index != 0 && (
                              <div className="ml-auto w-fit flex">
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  className="hover:bg-destructive/10"
                                  onClick={() => removeExpense(index)}
                                >
                                  <Trash className="h-4 w-4 text-destructive" />
                                </Button>
                              </div>
                            )}
                            <FormFieldInput
                              control={form.control}
                              name={`expenses.${index}.title`}
                              label="Expense Title"
                              placeholder="Enter a title for this expense"
                            />

                            <SplitExpense
                              control={form.control}
                              expenseIndex={index}
                              totalAmount={amount}
                            />

                            <div className="grid grid-cols-2 gap-4">
                              <FormFieldInput
                                control={form.control}
                                name={`expenses.${index}.amount`}
                                label="Amount"
                                placeholder="Enter Amount"
                                type="number"
                                inputMode="numeric"
                              />
                              <FormFieldSelect
                                control={form.control}
                                name={`expenses.${index}.category`}
                                values={categoryOptions}
                                placeholder="Select Category"
                                label="Expense Category"
                              />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <FormFieldInput
                                control={form.control}
                                name={`expenses.${index}.vendor`}
                                label="Merchant"
                                placeholder="Enter Merchant"
                              />
                              <FormFieldCalendar
                                control={form.control}
                                name={`expenses.${index}.transactionDate`}
                                label="Transaction Date"
                              />
                            </div>

                            <FormFieldTextArea
                              control={form.control}
                              label="Description"
                              name={`expenses.${index}.description`}
                              placeholder=""
                            />

                            {index === fields.length - 1 && (
                              <Button
                                type="button"
                                variant={"link"}
                                className="text-primary underline text-base font-bold leading-[150%] w-fit ml-auto place-self-end"
                                onClick={addExpense}
                              >
                                Add Another
                              </Button>
                            )}
                          </div>
                          <div className="max-w-sm">
                            <Label className="text-xs leading-[125%] font-normal text-foreground mb-1.5 block">
                              Receipt
                            </Label>
                            <div className="rounded-lg border border-border bg-white p-3 h-[420px] flex items-center justify-center">
                              {files[index] ? (
                                <img
                                  src={files[index]}
                                  alt="Uploaded receipt"
                                  className="w-full h-full object-contain"
                                />
                              ) : (
                                <div className="text-sm text-muted-foreground text-center px-6 space-y-3">
                                  <div className="text-muted-foreground font-medium">
                                    No receipt uploaded for this item.
                                  </div>
                                  <div className="text-muted-foreground">
                                    Receipt is required for final submission.
                                    You can save as draft without a receipt.
                                  </div>
                                  <input
                                    id={`receipt-input-${index}`}
                                    type="file"
                                    accept="image/*"
                                    aria-label={`Upload receipt for item ${index + 1}`}
                                    className="hidden"
                                    onChange={(e) => onReceiptSelect(index, e)}
                                  />
                                  <Button
                                    type="button"
                                    variant="outlinePrimary"
                                    onClick={() => {
                                      document
                                        .getElementById(
                                          `receipt-input-${index}`,
                                        )
                                        ?.click();
                                    }}
                                  >
                                    Continue to upload receipt
                                  </Button>
                                </div>
                              )}
                            </div>
                            <FormField
                              control={form.control}
                              name={`expenses.${index}.receipt`}
                              render={() => (
                                <FormItem className="pt-2">
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              )}

              {/* Form Actions */}
              <div className="flex space-x-4 pt-10">
                <Button
                  type="submit"
                  size={"md"}
                  disabled={
                    !hasAllReceipts || isSubmitting || isLoadingCategories
                  }
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      Submit{" "}
                      {fields.length > 1
                        ? `${fields.length} Expenses`
                        : "Expense"}
                    </>
                  )}
                </Button>
                <Button
                  type="button"
                  variant="outlinePrimary"
                  onClick={() => { // Removed 'async' as mutate is not awaited directly
                    const values = form.getValues();
                    // Trigger validation so required fields are respected.
                    form.handleSubmit((validData) => { // Removed 'async'
                      // Build payload WITHOUT receipts (for draft)
                      const payload = buildExpensePayload(
                        validData as ExpenseFormValues,
                        false,
                      );

                      console.log("Saving draft payload:", payload);

                      saveExpenseAsDraft({ ...payload, status: "draft" }); // Use the mutation
                    })();
                  }}
                  size={"md"}
                  disabled={isSubmitting || isLoadingCategories}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    "Save As Draft"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </>
      </div>
    </>
  );
}
