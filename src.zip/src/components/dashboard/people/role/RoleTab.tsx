
import RoleTable from "./RoleTable";



export const RolesTab = () => {
    return (
        <div className="space-y-4">
            <RoleTable />
        </div>
    );
};