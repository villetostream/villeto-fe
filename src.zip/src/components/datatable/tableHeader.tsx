import React, { JSX } from "react";
import { Table } from "@tanstack/react-table";

import { Filter, FilterData } from "./filter";
import { Download, SearchIcon, Settings } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";
import { Button } from "../ui/button";
import { Checkbox } from "../ui/checkbox";

export interface ITableHeader {
  isSearchable?: boolean;
  isExportable?: boolean;
  isFilter?: boolean;
  actionButton?: JSX.Element;
  downloadExportDataFunc?: () => Promise<Record<string, unknown>[]>;
  searchQuery?: (e: any) => void;
  search?: string;
  filterProps?: {
    title: string;
    filterData: FilterData[];
    onFilter: (data: Record<string, unknown>) => void;
  };
  bulkActions?: { label: string; onClick: () => void }[];
  enableColumnVisibility?: boolean;
}

export function TableHeader({
  tableHeader,
  handleExport,
  selectedCount = 0,
  selectedData = [],
  enableColumnVisibility = false,
  table,
}: {
  tableHeader?: ITableHeader;
  handleExport: () => void;
  selectedCount?: number;
  selectedData?: any[];
  enableColumnVisibility?: boolean;
  table?: Table<any>;
}) {
  return (
    <div>
      {/* Bulk Actions Bar - Show when items are selected */}
      {selectedCount > 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-md p-3 mb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <span className="text-sm font-medium text-blue-900">
                {selectedCount} item{selectedCount > 1 ? "s" : ""} selected
              </span>
              <div className="flex space-x-2">
                {tableHeader?.bulkActions?.map((bulkAction) => (
                  <button
                    key={bulkAction.label}
                    onClick={bulkAction.onClick}
                    className="px-3 py-1 text-xs font-medium text-blue-700 bg-blue-100 hover:bg-blue-200 rounded-md transition-colors"
                  >
                    {bulkAction.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
      <div className="flex sm:flex-row flex-col items-center gap-2 md:space-x-2 space-x-0 space-y-2 md:space-y-0 font-semibold text-md mb-4 bg-white justify-end relative">
        <div className="flex sm:flex-row flex-col items-center gap-2 absolute right-0 -top-12.5">
          {tableHeader?.actionButton && <div>{tableHeader.actionButton}</div>}

          {tableHeader?.isSearchable && (
            <div
              className={`flex items-center border rounded-md focus-within:ring-2 focus-within:ring-primary max-w-sm w-full`}
            >
              <span className="pl-3 text-gray-400">
                <SearchIcon className="w-4 h-4" />
              </span>

              <input
                id="searchInput"
                type="text"
                placeholder="Search..."
                value={tableHeader.search}
                onChange={(e) => tableHeader.searchQuery?.(e.target.value)}
                className="px-1 py-2 w-full !focus:outline-none bg-transparent !focus:ring-0 in-focus-visible:ring-0 border-0"
              />
            </div>
          )}

          {tableHeader?.isFilter && (
            <>
              {tableHeader?.filterProps && (
                <Filter filterProps={tableHeader.filterProps} />
              )}
            </>
          )}
          {enableColumnVisibility && table && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="h-10">
                  <Settings className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[200px]">
                <DropdownMenuLabel>Toggle columns</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {table
                  .getAllColumns()
                  .filter((column) => column.getCanHide())
                  .map((column) => {
                    return (
                      <DropdownMenuItem
                        key={column.id}
                        className="capitalize"
                        onClick={() =>
                          column.toggleVisibility(!column.getIsVisible())
                        }
                      >
                        <Checkbox
                          checked={column.getIsVisible()}
                          onChange={() => {}}
                          className="mr-2"
                        />
                        {typeof column.columnDef.header === "string"
                          ? column.columnDef.header
                          : column.id}
                      </DropdownMenuItem>
                    );
                  })}
              </DropdownMenuContent>
            </DropdownMenu>
          )}

          {tableHeader?.isExportable && (
            <div
              onClick={handleExport}
              className="flex items-center justify-center w-10 h-10 rounded-md bg-gray-100 hover:bg-gray-200 cursor-pointer"
            >
              <Download />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
