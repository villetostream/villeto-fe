export const STATE_KEYS = {
  DELETE: "delete",
  SUCCESS: "success"
} as const;
