export const titleStyle = "text-3xl md:text-[34px] font-semibold  leading-[100%]";
export const subTitleStyle = "text-xl leading-[34px]  font-light text-left tracking-[0%]";
export const divTitleStyle = 'text-left max-w-8/12 space-y-2.5 fade-in';