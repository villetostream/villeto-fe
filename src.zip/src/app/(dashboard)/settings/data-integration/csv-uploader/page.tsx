import CSVProcessor from '@/components/uploads/CsvProcessor'
import React from 'react'

const page = () => {
    return (
        <CSVProcessor />
    )
}

export default page