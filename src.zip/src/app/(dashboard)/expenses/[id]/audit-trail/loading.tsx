import PageLoading from '@/components/ui/page-loading';

export default PageLoading; 
