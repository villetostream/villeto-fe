"use client";
import { ManualExpenseForm } from '@/components/expenses/ManualExpenseForm'
import React from 'react'

const page = () => {
    return (
        <ManualExpenseForm />
    )
}

export default page;
